public class Rook extends Piece {
    
    /**
     * constructor.
     */
    public Rook(int coordinatesX, int coordinatesY) {
        super(coordinatesX, coordinatesY);
    }

    public Rook(int coordinatesX, int coordinatesY, String color) {
        super(coordinatesX, coordinatesY, color);
    }

    public String getSymbol() {
        return "R";
    }

    /**
     * ham kiem tra xe co di duoc ko.
     */
    public boolean canMove(Board board, int x, int y) {
        if (x != getCoordinatesX() && y != getCoordinatesY()) {
            return false;
        }
        if (x == getCoordinatesX()) {
            int yy = getCoordinatesY();
            if (yy < y) {
                for (int i = yy + 1; i < y; i++) {
                    if (board.getAt(x, i) != null) {
                        return false;
                    }
                }
                if (board.getAt(x, y) != null) {
                    if (board.getAt(x, y).getColor().equals(getColor())) {
                        return false;
                    }
                }
            }   else if (yy > y) {
                    for (int i = yy - 1; i > y; i--) {
                        if (board.getAt(x, i) != null) {
                            return false;
                        }
                    }
                    if (board.getAt(x, y) != null) {
                        if (board.getAt(x, y).getColor().equals(getColor())) {
                            return false;
                        }
                    }
            }
        }
        if (y == getCoordinatesY()) {
            int xx = getCoordinatesX();
            if (xx < x) {
                for (int i = xx + 1; i < x; i++) {
                    if (board.getAt(i, y) != null) {
                        return false;
                    }
                }
                if (board.getAt(x, y) != null) {
                    if (board.getAt(x, y).getColor().equals(getColor())) {
                        return false;
                    }
                }
            }   else if (xx > x) {
                    for (int i = xx - 1; i > x; i--) {
                        if (board.getAt(i, y) != null) {
                            return false;
                        }
                    }
                    if (board.getAt(x, y) != null) {
                        if (board.getAt(x, y).getColor().equals(getColor())) {
                            return false;
                        }
                    }
            }
        }
        return true;
    }
}
